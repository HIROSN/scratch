$(function() {

  var $mouse = $('#mouse');
  var $floor = $('#floor');

  // TODO: to keep the mouse inside the bounds of the #floor,
  // you'll need to figure out how far the mouse can scamper in
  // either direction before hitting a wall.
  // note: you need to know both the dimensions of the floor
  // and the dimensions of the mouse.
  // you'll use these values in the 'scamper' method below
  var xMax = $floor.width() - $mouse.width(); // TODO: initialize me
  var yMax = $floor.height() - $mouse.height(); // TODO: initialize me

  // constants
  var MOVE_LENGTH = 50; // pixels
  var MOVE_TIME = 300; // milliseconds
  var DIRECTIONS = ['up', 'down', 'left', 'right'];

  // give top and left position properties initial values
  $mouse.css('top', 0);
  $mouse.css('left', 0);

  // TODO: register an event handler to respond to a win
  $mouse.click(function() {
    alert('Your kitty ninja skillz have prevailed.');
  });

  $(window).on('resize', function() {
    xMax = $floor.width() - $mouse.width();
    yMax = $floor.height() - $mouse.height();
  });

  // TODO: scamper the mouse MOVE_LENGTH pixels in a direction
  // randomly chosen from array DIRECTIONS
  // be sure to call boundValue on the input in order to keep
  // the mouse within the floor boundaries.
  // note:
  // to scamper the mouse right, you add to the "left" position property.
  // to scamper the mouse down, you add to the "top" position property.
  function scamper() {
    // TODO: implement me
    // TODO: call randomDirection
    // TODO: use the current function (twice)
    // TODO: call boundValue (twice) somewhere in here
    // to make sure the mouse stays on the floor
    var top = current('top');
    var left = current('left');
    var newTop = top;
    var newLeft = left;
    var direction;

    while (newTop === top && newLeft === left) {
      direction = randomDirection();

      switch (direction) {
        case 'up':    newTop  -= MOVE_LENGTH; break;
        case 'down':  newTop  += MOVE_LENGTH; break;
        case 'left':  newLeft -= MOVE_LENGTH; break;
        case 'right': newLeft += MOVE_LENGTH; break;
      }

      newTop = boundValue(newTop, yMax);
      newLeft = boundValue(newLeft, xMax);
    }

    $mouse.css('background-image', 'url("' + direction + '.png")');

    if (newTop !== top) {
      $mouse.animate({top: newTop}, MOVE_TIME);
    }
    else {
      $mouse.animate({left: newLeft}, MOVE_TIME);
    }
  }

  // start the mouse running
  // plus 10 ms to put some padding between the
  // animation and the next interval
  // don't change the following line.
  setInterval(scamper, MOVE_TIME + 10);

  // ----------------------------------------
  // helpers
  // ----------------------------------------

  // bound value between 0 and max
  // TODO: use me in the scamper method
  function boundValue(value, max) {
    //TODO: implement me
    return value < 0 ? 0 : value > max ? max : value;
  }

  // TODO: use me in the scamper method
  function randomDirection() {
    // TODO: randomly select and return one of the values in
    // implement me
    // the array DIRECTIONS
    return DIRECTIONS[Math.floor(Math.random() * DIRECTIONS.length)];
  }

  // positionProperty should be one of
  // "top", "left", "right", or "bottom"
  // TODO: use me in the scamper method
  function current(positionProperty) {
    // TODO: return an integer representing the specified
    // implement me
    // position property (where the mouse currently is)
    return parseInt($mouse.css(positionProperty));
  }
});
